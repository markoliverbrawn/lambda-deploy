exports.handler = (event, context, callback) => {
    // TODO implement
    callback(null, 'Goodbye from Lambda');
};
